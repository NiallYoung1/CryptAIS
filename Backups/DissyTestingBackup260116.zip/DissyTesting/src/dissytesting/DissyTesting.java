package dissytesting;

import java.util.*;
import java.io.*;


public class DissyTesting 
{

    //Cipher Text File
    public static String cipherTextFileName = "C://cipher.txt"; 
    
    //Lines of the text file
    public static ArrayList<String> input = new ArrayList<>();
    
    //Total number of characters in ciphertext
    public static int characterCount = 0;
    
    //This is the Map for the counting of characters in the Ciphertext.
    public static LinkedHashMap<String,Integer> charCounter = new LinkedHashMap<>();
    
    //This is the Map for the frequency of characters in the Ciphertext.
    public static LinkedHashMap<String,Double> ciphertextLetterFrequencies = new LinkedHashMap<>();
    
    //This is the Map for the standard count of characters in the english language.
    public static LinkedHashMap<String,Double> plaintextLetterFrequencies = new LinkedHashMap<>();
    
    //English Alphabet
    public static String alphabet = "abcdefghijklmnopqrstuvwxyz";
    
    
    
    
    public static void main(String[] args) 
    {        
        DissyTesting test = new DissyTesting();
        test.getInput();
        test.printInput();
        test.alphabetCounter();
        test.totalCharCount();
        test.setUpPlaintextFrequencies();
        test.setUpCiphertextFrequencies();
        
        for(String S:ciphertextLetterFrequencies.keySet())
        {
            System.out.println("The Character: " + S + " appears " + ciphertextLetterFrequencies.get(S) + " times");
        }
        
        System.out.println("Total number of Characters: " + characterCount);
        
    }
    
    //This will take the standard frequencies from the english language as found in Robert Lewand's book Cryptological mathematics: http://bit.ly/1UonJo9
    public void setUpPlaintextFrequencies()
    {
        plaintextLetterFrequencies.put("a", 0.08167);
        plaintextLetterFrequencies.put("b", 0.01492);
        plaintextLetterFrequencies.put("c", 0.02782);
        plaintextLetterFrequencies.put("d", 0.04253);
        plaintextLetterFrequencies.put("e", 0.12702);
        plaintextLetterFrequencies.put("f", 0.02228);
        plaintextLetterFrequencies.put("g", 0.02015);
        plaintextLetterFrequencies.put("h", 0.06094);
        plaintextLetterFrequencies.put("i", 0.06966);
        plaintextLetterFrequencies.put("j", 0.00153);
        plaintextLetterFrequencies.put("k", 0.00772);
        plaintextLetterFrequencies.put("l", 0.04025);
        plaintextLetterFrequencies.put("m", 0.02406);
        plaintextLetterFrequencies.put("n", 0.06749);
        plaintextLetterFrequencies.put("o", 0.07507);
        plaintextLetterFrequencies.put("p", 0.01929);
        plaintextLetterFrequencies.put("q", 0.00095);
        plaintextLetterFrequencies.put("r", 0.05987);
        plaintextLetterFrequencies.put("s", 0.06327);
        plaintextLetterFrequencies.put("t", 0.09056);
        plaintextLetterFrequencies.put("u", 0.02758);
        plaintextLetterFrequencies.put("v", 0.00978);
        plaintextLetterFrequencies.put("w", 0.02360);
        plaintextLetterFrequencies.put("x", 0.00150);
        plaintextLetterFrequencies.put("y", 0.01974);
        plaintextLetterFrequencies.put("z", 0.00074);
    }
    
    //This will calculate the frequencies from the ciphertext given
    public void setUpCiphertextFrequencies()
    {
        //for all letters in the alphabet calculate the %age(5 decimal places) probability        
        for(String S:charCounter.keySet())
        {
            //probability rounded to 5 decimal places
            double probability = (double)Math.round(   ((double) charCounter.get(S)/characterCount) * 100000d  )/100000d;
            ciphertextLetterFrequencies.put(S,probability);
            //System.out.println("WORKING " + probability + " " + charCounter.get(S) + " " + characterCount);
        }
        
    }
    
    //this method gets the total character count
    public void totalCharCount()
    {
        //
        for(String S:charCounter.keySet())
        {
            characterCount += charCounter.get(S);
        }
    }
    
    //this method populates the charCounter
    public void alphabetCounter()
    {
        //HashMap<String,Integer> counter = new HashMap<String,Integer>();
        
        for(int i = 0; i<alphabet.length(); i++)
        {
            //
            char temp = alphabet.charAt(i);
            charCounter.put(""+temp, 0);
        }
        
        //For each line of input
        for(String line:input)
        {
            //For each letter
            for(int i = 0; i<line.length(); i++)
            {
                //Increment total Char count
                //characterCount++;
                
                //Increment letter total
                char temp = line.charAt(i);
                if(alphabet.contains("" + temp))
                {
                    charCounter.put(""+temp, charCounter.get(""+temp)+1 );
                }
            }
        }
    }
    
    public void printInput()
    {
        for(int i = 0; i<input.size(); i++ )
        {
            //System.out.println(input.get(i));
        }
    }
    
    //This method populates the raw arraylist input
    public void getInput()
    {
		
        String line;
		
        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(cipherTextFileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            //Values to keep place in the input
            int blankCounter = 0;
            //int lineCounter = 0;
            String currentVariableName = "";
            
            //While there are still lines to be read
            while((line = bufferedReader.readLine()) != null) 
            {
            	//add to arraylist
                //System.out.println("This fired");
                input.add(line.toLowerCase());
            }   
            
            //System.out.println(blankCounter);
            
            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) 
	{
            System.out.println("Unable to open file '" + cipherTextFileName + "'");
        }
        catch(IOException ex) 
	{
        	System.out.println("Error reading file '" + cipherTextFileName + "'");
        }
    }
}
